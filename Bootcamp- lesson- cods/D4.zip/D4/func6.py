def do():
    pass

print(do())

def do():
    return 1

print(do())