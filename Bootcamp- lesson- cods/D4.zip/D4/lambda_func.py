def add_two(num1, num2):
    return num1 + num2

add_two = lambda num1, num2: num1 + num2

print(add_two(1,2))