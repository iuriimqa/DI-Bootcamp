def print_something() -> None:
    print("SOMETHING")

for i in range(20):
    print_something()

