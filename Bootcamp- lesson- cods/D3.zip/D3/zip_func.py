numbers_1 = [num for num in range(11)]
numbers_2 = [num for num in range(11, 21)]

connected = list(zip(numbers_1, numbers_2))

print(connected)