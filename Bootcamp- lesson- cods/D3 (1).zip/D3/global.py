def calculate():
    global n 
    n = 5


calculate()
print(n)

def change():
    print(n)


change()