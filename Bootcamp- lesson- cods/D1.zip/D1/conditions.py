sun = 'up'

if 2 != 2 or sun == 'up':
    # OR - at least 1 condition returns True
    print("Equal")

if 2 == 2 and sun == 'up':
    # AND - ALL of the conditions return True
    # identation (4 spaces) 
    print("Equal")
 

apple = 'yellow'
winner = True

if apple == 'red' or winner == False:
    print('True')
else:
    print('All is False')


apple = 'yellow'
winner = True

if apple == 'red':
    print('Apple RED')
elif winner: # Elif (Else if) takes the previous if in account
    print('Winner True')
else:
    print('ALL IS FALSE!')
