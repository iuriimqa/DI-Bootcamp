# input
# user_input = input("Your input here: ")
# print(user_input)

num1_str = input('Provide number: ')
num1_int = int(num1_str)

print(num1_int + 10)